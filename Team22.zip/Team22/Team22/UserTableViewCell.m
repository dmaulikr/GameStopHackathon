//
//  UserTableViewCell.m
//  Team22
//
//  Created by BYOUNGJUN JO on 11/14/15.
//  Copyright (c) 2015 SJSU. All rights reserved.
//

#import "UserTableViewCell.h"

@implementation UserTableViewCell

@end
